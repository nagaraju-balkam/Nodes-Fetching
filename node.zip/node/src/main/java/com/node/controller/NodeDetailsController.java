package com.node.controller;

import java.util.List;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.node.model.NodeDetails;
import com.node.repo.NodeDetailsRepo;
import com.node.service.NodeDetailsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/nodes")
@Validated
public class NodeDetailsController {
	 @Autowired
	    private NodeDetailsService nodeDetailsService; 

//	    @PostMapping
//	    public ResponseEntity<NodeDetails> createNode(@Valid @RequestBody NodeDetails nodeDetails) {
//	        NodeDetails createdNode = nodeDetailsService.createNode(nodeDetails);
//	        return new ResponseEntity<>(createdNode, HttpStatus.CREATED);
//	    }
	 @PostMapping
	    public ResponseEntity<NodeDetails> createNode(@Valid @RequestBody NodeDetails nodeDetails) {
	        NodeDetails createdNode = nodeDetailsService.createNode(nodeDetails);
	        return new ResponseEntity<>(createdNode, HttpStatus.CREATED);
	    }
	    
	    @GetMapping
	    public ResponseEntity<List<NodeDetails>> getNodes(){
	    	
	    	return new ResponseEntity<>(nodeDetailsService.findAllNodes(),HttpStatus.OK);
	    }

}
