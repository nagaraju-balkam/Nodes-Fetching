package com.node.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
public class NodeDetails {

 	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int NodeId;

 	@NotBlank(message = "NodeName cannot be null or blank")
    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "NodeName contains invalid characters")
    private String NodeName;

 	@NotBlank(message = "Description cannot be null or blank")
    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "Description contains invalid characters")
    private String Description;

    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "Memo contains invalid characters")
    private String Memo;

    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "NodeType contains invalid characters")
    private String NodeType;

    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "ParentNodeGroupName contains invalid characters")
    private String ParentNodeGroupName;

    @Pattern(regexp = "^[a-zA-Z0-9 ]*$", message = "ParentNodeGroupId contains invalid characters")
    private String ParentNodeGroupId;
    
    
    public NodeDetails() {
    	
    }

	public NodeDetails(int nodeId, String nodeName, String description, String memo, String nodeType,
			String parentNodeGroupName, String parentNodeGroupId) {
		super();
		NodeId = nodeId;
		NodeName = nodeName;
		Description = description;
		Memo = memo;
		NodeType = nodeType;
		ParentNodeGroupName = parentNodeGroupName;
		ParentNodeGroupId = parentNodeGroupId;
	}

	@Override
	public String toString() {
		return "NodeDetails [NodeId=" + NodeId + ", NodeName=" + NodeName + ", Description=" + Description + ", Memo="
				+ Memo + ", NodeType=" + NodeType + ", ParentNodeGroupName=" + ParentNodeGroupName
				+ ", ParentNodeGroupId=" + ParentNodeGroupId + "]";
	}

	public int getNodeId() {
		return NodeId;
	}

	public void setNodeId(int nodeId) {
		NodeId = nodeId;
	}

	public String getNodeName() {
		return NodeName;
	}

	public void setNodeName(String nodeName) {
		NodeName = nodeName;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getMemo() {
		return Memo;
	}

	public void setMemo(String memo) {
		Memo = memo;
	}

	public String getNodeType() {
		return NodeType;
	}

	public void setNodeType(String nodeType) {
		NodeType = nodeType;
	}

	public String getParentNodeGroupName() {
		return ParentNodeGroupName;
	}

	public void setParentNodeGroupName(String parentNodeGroupName) {
		ParentNodeGroupName = parentNodeGroupName;
	}

	public String getParentNodeGroupId() {
		return ParentNodeGroupId;
	}

	public void setParentNodeGroupId(String parentNodeGroupId) {
		ParentNodeGroupId = parentNodeGroupId;
	}


   
}
