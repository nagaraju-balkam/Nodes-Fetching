package com.node.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.node.model.NodeDetails;

public interface NodeDetailsRepo extends JpaRepository<NodeDetails, Integer> {
	
	// NodeDetails save(NodeDetails nodeDetails);
}
