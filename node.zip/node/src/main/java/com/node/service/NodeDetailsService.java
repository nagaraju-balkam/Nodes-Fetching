package com.node.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.node.model.NodeDetails;
import com.node.repo.NodeDetailsRepo;

@Service
public class NodeDetailsService {

    @Autowired
    private NodeDetailsRepo repository;
    
//    public NodeDetails saveNode(NodeDetails nodeDetails) {
//        // Save the nodeDetails to the database
//        return repository.save(nodeDetails);
//    }
    
    public NodeDetails createNode(NodeDetails nodeDetails) {
        return repository.save(nodeDetails);
    }
    public List<NodeDetails> findAllNodes() {
        return repository.findAll();
    }

}
